var namespacens_exception =
[
    [ "CException", "classns_exception_1_1_c_exception.html", "classns_exception_1_1_c_exception" ],
    [ "kError", "namespacens_exception.html#af1e302dd5a468c59cfa32ee30bc6503a", null ]
];