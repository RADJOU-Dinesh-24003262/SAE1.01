var classns_gui_1_1_text =
[
    [ "HorizontalAlignment", "classns_gui_1_1_text.html#a78bb37c174a4f37eec2b7d69459ee7dc", [
      [ "ALIGNH_LEFT", "classns_gui_1_1_text.html#a78bb37c174a4f37eec2b7d69459ee7dca7b5a51aac14cb50d1840e3f3de485ac2", null ],
      [ "ALIGNH_CENTER", "classns_gui_1_1_text.html#a78bb37c174a4f37eec2b7d69459ee7dca79703335d1d5367bd5ee2387413c17a9", null ],
      [ "ALIGNH_RIGHT", "classns_gui_1_1_text.html#a78bb37c174a4f37eec2b7d69459ee7dca464315bc1bcc242334d76eb8b0d1e8f6", null ]
    ] ],
    [ "TransitionIds", "classns_gui_1_1_text.html#a5fa355035f5afc9c896fa8138c29ea09", [
      [ "TRANSITION_COLOR_RGB", "classns_gui_1_1_text.html#a5fa355035f5afc9c896fa8138c29ea09a91cb0804f8ea9e7353a36a52d89fc492", null ],
      [ "TRANSITION_COLOR_ALPHA", "classns_gui_1_1_text.html#a5fa355035f5afc9c896fa8138c29ea09a508f66b682f94f547d3f56062aa1fb3f", null ],
      [ "TRANSITION_POSITION", "classns_gui_1_1_text.html#a5fa355035f5afc9c896fa8138c29ea09a83fc6bac538e3af4f423c8a4cd0585b8", null ]
    ] ],
    [ "VerticalAlignment", "classns_gui_1_1_text.html#a3b0b5071a55982d5612c457a832f80fa", [
      [ "ALIGNV_TOP", "classns_gui_1_1_text.html#a3b0b5071a55982d5612c457a832f80faa3cfba6c9f9e078a9fcd6c4133ecb4c30", null ],
      [ "ALIGNV_CENTER", "classns_gui_1_1_text.html#a3b0b5071a55982d5612c457a832f80faa37d3b49647821b7b1808dcd159867a45", null ],
      [ "ALIGNV_BOTTOM", "classns_gui_1_1_text.html#a3b0b5071a55982d5612c457a832f80faace396f1024afc2c37173ea637856e25f", null ]
    ] ],
    [ "Text", "classns_gui_1_1_text.html#a2d86c3b73f670c0ae206c4f35401a09f", null ],
    [ "computeHeight", "classns_gui_1_1_text.html#a40e2854b349731f1cdc0574e7297bc50", null ],
    [ "computeVisibleEndPosition", "classns_gui_1_1_text.html#af8a352a5cb3b4f849eda7badc11fbb31", null ],
    [ "computeVisiblePosition", "classns_gui_1_1_text.html#aa05c15547863bb237374487fe9ccfd2e", null ],
    [ "computeWidth", "classns_gui_1_1_text.html#a5ad119bf3e6c774c00711bb302f4bb1e", null ],
    [ "draw", "classns_gui_1_1_text.html#a8b3f43f7582246e916bb2e9403be2180", null ],
    [ "getContent", "classns_gui_1_1_text.html#adea76711a628669e54020b282152e389", null ],
    [ "getHorizontalAlignment", "classns_gui_1_1_text.html#aa32517dfacf2084151b75a136ac9aa45", null ],
    [ "getPosition", "classns_gui_1_1_text.html#a1e06796a15191e7682eb4abd0ecc515e", null ],
    [ "getTextColor", "classns_gui_1_1_text.html#a248f06b3a9a85c05225449424311abd0", null ],
    [ "getTextFont", "classns_gui_1_1_text.html#aa5c850b0dca59db5a31767721909a25e", null ],
    [ "getValues", "classns_gui_1_1_text.html#a6ddbea2ef54c442d44d6e624df486ad7", null ],
    [ "getVerticalAlignment", "classns_gui_1_1_text.html#a9767b9b26f8e63ad40318984390c022d", null ],
    [ "setContent", "classns_gui_1_1_text.html#a930caeda954e7517aa34bc5965c8709f", null ],
    [ "setHorizontalAlignment", "classns_gui_1_1_text.html#a952d6bb9e10c33aa446ff17fd73944a9", null ],
    [ "setPosition", "classns_gui_1_1_text.html#ae258c9cd1203c3e52b7728e0211e9daa", null ],
    [ "setTextColor", "classns_gui_1_1_text.html#a9e10bb21647ce95f034a4205562e222a", null ],
    [ "setTextFont", "classns_gui_1_1_text.html#afa19265ff44bdab288fa2a7100dd9c50", null ],
    [ "setValues", "classns_gui_1_1_text.html#a9fbd7627d5cc5eaa7259f475c73aec73", null ],
    [ "setVerticalAlignment", "classns_gui_1_1_text.html#a5b0a3b1a3d31129f2d8aa32b58ea2f8a", null ]
];