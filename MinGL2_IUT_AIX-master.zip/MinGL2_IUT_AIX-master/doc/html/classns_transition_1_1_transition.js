var classns_transition_1_1_transition =
[
    [ "TransitionFinishModes", "classns_transition_1_1_transition.html#a0bf761e331527477ce0c5e496b722a19", [
      [ "FINISH_START", "classns_transition_1_1_transition.html#a0bf761e331527477ce0c5e496b722a19a87bacef756b461171816412a31e19ad4", null ],
      [ "FINISH_CURRENT", "classns_transition_1_1_transition.html#a0bf761e331527477ce0c5e496b722a19a4d57dbd11ced739957f0609922a6dc9f", null ],
      [ "FINISH_DESTINATION", "classns_transition_1_1_transition.html#a0bf761e331527477ce0c5e496b722a19ad32a777c01bab232b51e5eeb31e2b03e", null ]
    ] ],
    [ "Transition", "classns_transition_1_1_transition.html#a7c3e692c43aceca5e4f716f3ae22bf05", null ],
    [ "addToElapsed", "classns_transition_1_1_transition.html#abb421b44828c7b6dec60a0256a97b3d9", null ],
    [ "finish", "classns_transition_1_1_transition.html#a8c8c7caf7326e24ffa540093ed12f581", null ],
    [ "getElapsed", "classns_transition_1_1_transition.html#a616e0ef596d4e8ebb185a6cf0a685924", null ],
    [ "isFinished", "classns_transition_1_1_transition.html#ad9d358bee54825d2a8bf83e9e21e398b", null ],
    [ "isReversed", "classns_transition_1_1_transition.html#ab32ef25219cd2227746444ac8794266a", null ],
    [ "setElapsed", "classns_transition_1_1_transition.html#a0a8e848a50c2e05dc72800abfc6dd6ef", null ]
];