var dir_58474cfd5d84c833dfefa558add7f0ec =
[
    [ "bgtext.h", "08-_custom_drawable_2bgtext_8h_source.html", null ]
];