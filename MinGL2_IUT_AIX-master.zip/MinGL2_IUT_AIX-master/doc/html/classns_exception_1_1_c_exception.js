var classns_exception_1_1_c_exception =
[
    [ "CException", "classns_exception_1_1_c_exception.html#aeacba2e2180dd8c00c643e1a67cba423", null ],
    [ "~CException", "classns_exception_1_1_c_exception.html#a8b95a8f59d50a7ff3b67423c83cb8501", null ],
    [ "_Edit", "classns_exception_1_1_c_exception.html#ae4430e1cfaa948dc6f63bb8437fa6027", null ],
    [ "GetCodErr", "classns_exception_1_1_c_exception.html#adf06d1598420c7b60c1b134bf2a946c2", null ],
    [ "GetLibelle", "classns_exception_1_1_c_exception.html#aef8e3d1a4e22ec7045d7d0b14d8b968a", null ],
    [ "what", "classns_exception_1_1_c_exception.html#a5ef0ababcc3ffc93f70211de1122c9a8", null ],
    [ "m_CodErr", "classns_exception_1_1_c_exception.html#a9610371f15e2c6d99034c46b632d51da", null ],
    [ "m_Libelle", "classns_exception_1_1_c_exception.html#a96c2d653703b2879ff8050cc78bc450a", null ]
];