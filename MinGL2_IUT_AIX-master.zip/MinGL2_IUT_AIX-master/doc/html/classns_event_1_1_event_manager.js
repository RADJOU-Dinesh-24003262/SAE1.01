var classns_event_1_1_event_manager =
[
    [ "clearEvents", "classns_event_1_1_event_manager.html#adbc5ced9a9435f61f58436ff613632b4", null ],
    [ "hasEvent", "classns_event_1_1_event_manager.html#a5a3119d969a296b8e94f223171fdf2e6", null ],
    [ "pullEvent", "classns_event_1_1_event_manager.html#adb00a0a006f4caa976471e74bf99cdc9", null ],
    [ "pushEvent", "classns_event_1_1_event_manager.html#a1eff8398ddb0a25da82e52a1067b85b5", null ]
];