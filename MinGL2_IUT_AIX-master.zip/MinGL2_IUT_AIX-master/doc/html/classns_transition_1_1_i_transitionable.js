var classns_transition_1_1_i_transitionable =
[
    [ "~ITransitionable", "classns_transition_1_1_i_transitionable.html#addd11ff845b6387b07672a64c1b8938e", null ],
    [ "getValues", "classns_transition_1_1_i_transitionable.html#a5871a16fd47c1e5c8bacdd5da8597ed9", null ],
    [ "setValues", "classns_transition_1_1_i_transitionable.html#ade37d29f7f2ca4890ed0e2e64d033197", null ]
];