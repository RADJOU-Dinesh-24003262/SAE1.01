var event_8hpp =
[
    [ "MouseClickData_t", "structns_event_1_1_mouse_click_data__t.html", "structns_event_1_1_mouse_click_data__t" ],
    [ "MouseMoveData_t", "structns_event_1_1_mouse_move_data__t.html", "structns_event_1_1_mouse_move_data__t" ],
    [ "EventData_t", "unionns_event_1_1_event_data__t.html", "unionns_event_1_1_event_data__t" ],
    [ "Event_t", "structns_event_1_1_event__t.html", "structns_event_1_1_event__t" ],
    [ "EventType_t", "event_8hpp.html#a6e501b1114a041d127a56f51c66ada72", [
      [ "MouseClick", "event_8hpp.html#a6e501b1114a041d127a56f51c66ada72ac40555e94dcfb35e033e2314259db5f7", null ],
      [ "MouseMove", "event_8hpp.html#a6e501b1114a041d127a56f51c66ada72addbed44248cc7bf27e68c8e83a4af4c6", null ],
      [ "MouseDrag", "event_8hpp.html#a6e501b1114a041d127a56f51c66ada72a31c8442274463772ed6cc9c47bce8317", null ]
    ] ]
];