var classns_util_1_1_i_fonctor_unaire =
[
    [ "~IFonctorUnaire", "classns_util_1_1_i_fonctor_unaire.html#ae41ac6b220f0afa4b0860e92c27b3cd1", null ],
    [ "operator()", "classns_util_1_1_i_fonctor_unaire.html#a2f53e65b0a64a4eb543a709eb72ed3ab", null ]
];