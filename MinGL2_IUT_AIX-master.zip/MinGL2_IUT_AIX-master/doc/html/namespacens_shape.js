var namespacens_shape =
[
    [ "Circle", "classns_shape_1_1_circle.html", "classns_shape_1_1_circle" ],
    [ "Line", "classns_shape_1_1_line.html", "classns_shape_1_1_line" ],
    [ "Rectangle", "classns_shape_1_1_rectangle.html", "classns_shape_1_1_rectangle" ],
    [ "Shape", "classns_shape_1_1_shape.html", "classns_shape_1_1_shape" ],
    [ "Triangle", "classns_shape_1_1_triangle.html", "classns_shape_1_1_triangle" ]
];