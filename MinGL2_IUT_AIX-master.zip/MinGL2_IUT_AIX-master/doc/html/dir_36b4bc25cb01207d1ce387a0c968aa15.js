var dir_36b4bc25cb01207d1ce387a0c968aa15 =
[
    [ "bgtext.h", "09-_custom_transitionable_2bgtext_8h_source.html", null ]
];