var namespaces_dup =
[
    [ "img2si", null, [
      [ "convert_from_si2", "img2si_8py.html#a86753e07bbef076355a407a398a418bf", null ],
      [ "convert_to_si2", "img2si_8py.html#a07d658824b99acc387c6444863bebd5c", null ],
      [ "is_file_si2", "img2si_8py.html#ae37b6f3bba8bbf990c6f8c84cd2a79bd", null ],
      [ "main", "img2si_8py.html#afce854986e241b3a756dc2eb0a333f49", null ],
      [ "__author__", "img2si_8py.html#abcc3e8d7a68483db9b400f68496bd7f9", null ],
      [ "__license__", "img2si_8py.html#a5971fdb9af437359d12be6c17db92119", null ],
      [ "__version__", "img2si_8py.html#a416c93cc9556ba6f82fc8312a7d0558f", null ]
    ] ],
    [ "nsAudio", "namespacens_audio.html", "namespacens_audio" ],
    [ "nsEvent", "namespacens_event.html", "namespacens_event" ],
    [ "nsException", "namespacens_exception.html", "namespacens_exception" ],
    [ "nsGraphics", "namespacens_graphics.html", "namespacens_graphics" ],
    [ "nsGui", "namespacens_gui.html", "namespacens_gui" ],
    [ "nsShape", "namespacens_shape.html", "namespacens_shape" ],
    [ "nsTransition", "namespacens_transition.html", "namespacens_transition" ],
    [ "nsUtil", "namespacens_util.html", "namespacens_util" ]
];