var classns_shape_1_1_shape =
[
    [ "Shape", "classns_shape_1_1_shape.html#a879f450649c23c83dee576234703951d", null ],
    [ "~Shape", "classns_shape_1_1_shape.html#aaa22752af0d45c4e219e3870baf899d4", null ],
    [ "getBorderColor", "classns_shape_1_1_shape.html#aca75f4b06e8e5b04d0271d191210299d", null ],
    [ "getFillColor", "classns_shape_1_1_shape.html#a8efbd1ac47497b188edeb019557ef754", null ],
    [ "setBorderColor", "classns_shape_1_1_shape.html#a48821100aa1856f188bdba257505adc3", null ],
    [ "setFillColor", "classns_shape_1_1_shape.html#a6c0f6392753f72ed4c39424a83f7ed73", null ],
    [ "m_borderColor", "classns_shape_1_1_shape.html#a0444014e3ee0fa1e6ba5295e530a4f82", null ],
    [ "m_fillColor", "classns_shape_1_1_shape.html#a68841e117adddc95734dcbaa62f68832", null ]
];