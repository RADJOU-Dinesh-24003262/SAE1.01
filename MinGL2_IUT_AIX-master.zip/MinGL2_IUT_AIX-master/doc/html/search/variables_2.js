var searchData=
[
  ['datamagic_526',['datamagic',['../sprite_8h.html#a43e5468a3d445613419004493d2ffac8',1,'sprite.h']]]
];
