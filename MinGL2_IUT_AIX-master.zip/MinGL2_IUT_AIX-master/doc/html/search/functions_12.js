var searchData=
[
  ['what_512',['what',['../classns_exception_1_1_c_exception.html#a5ef0ababcc3ffc93f70211de1122c9a8',1,'nsException::CException']]]
];
