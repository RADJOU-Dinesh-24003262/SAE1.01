var searchData=
[
  ['bgtext_303',['BgText',['../class_bg_text.html',1,'']]]
];
