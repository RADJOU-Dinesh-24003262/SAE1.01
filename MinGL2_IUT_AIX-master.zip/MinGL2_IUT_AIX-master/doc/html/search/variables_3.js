var searchData=
[
  ['eventdata_527',['eventData',['../structns_event_1_1_event__t.html#a148669454c11351db2ac902aad495ac8',1,'nsEvent::Event_t']]],
  ['eventtype_528',['eventType',['../structns_event_1_1_event__t.html#a4658fcb9ee305cae39da30840d64192c',1,'nsEvent::Event_t']]]
];
