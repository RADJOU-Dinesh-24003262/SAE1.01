var classns_gui_1_1_sprite =
[
    [ "TransitionIds", "classns_gui_1_1_sprite.html#a09069244e6b3e580f8511496c7ae1b78", [
      [ "TRANSITION_POSITION", "classns_gui_1_1_sprite.html#a09069244e6b3e580f8511496c7ae1b78a90092e9cd093f4ef21dab0a68fbe6c54", null ]
    ] ],
    [ "Sprite", "classns_gui_1_1_sprite.html#a35558b08dfeb3e3a20be52da28e33c4c", null ],
    [ "Sprite", "classns_gui_1_1_sprite.html#abee8e5a2740555d46f19af3d4b489453", null ],
    [ "computeSize", "classns_gui_1_1_sprite.html#a263a6f2cc23794bd3c0395e78ef1ad8f", null ],
    [ "draw", "classns_gui_1_1_sprite.html#ac4b29170aef06d46990b68da76480f28", null ],
    [ "getPixelData", "classns_gui_1_1_sprite.html#ad8644780a7a7dcbcd5f2e4e7a461b685", null ],
    [ "getPosition", "classns_gui_1_1_sprite.html#a1d6ad6681627aae6c4680fc936da8eb2", null ],
    [ "getRowSize", "classns_gui_1_1_sprite.html#adbe04bd427b6658e0181ce167db83d05", null ],
    [ "getValues", "classns_gui_1_1_sprite.html#a7da27e2ccf7b574896662720d99c0056", null ],
    [ "setPosition", "classns_gui_1_1_sprite.html#a4c695910c46504d1e8d47b838394a48e", null ],
    [ "setValues", "classns_gui_1_1_sprite.html#a63ad7e76b470c578aecc697203a3eb26", null ]
];