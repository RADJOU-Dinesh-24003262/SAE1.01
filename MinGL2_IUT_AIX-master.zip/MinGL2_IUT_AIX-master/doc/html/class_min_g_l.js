var class_min_g_l =
[
    [ "KeyMap_t", "class_min_g_l.html#a084b1a739a671ad7d6af07792bd56af1", null ],
    [ "KeyType_t", "class_min_g_l.html#a6e612d21ed9723c37ad91093f7b48c96", null ],
    [ "MinGL", "class_min_g_l.html#aecc35a286d1adbcbdc76bf26df18169c", null ],
    [ "~MinGL", "class_min_g_l.html#a0f84e59dd311785a7e6da848abd5d188", null ],
    [ "clearScreen", "class_min_g_l.html#a86c940758616957683ffb2e239bba774", null ],
    [ "finishFrame", "class_min_g_l.html#a489922f0bdde2e38698adddaf57f6eda", null ],
    [ "getBackgroundColor", "class_min_g_l.html#a66758e8e6983cc1dd0b10b1ee743a65a", null ],
    [ "getEventManager", "class_min_g_l.html#ab558253439905930836ab4910a7ae253", null ],
    [ "getWindowName", "class_min_g_l.html#a46cea08ec9ef4a0678f425000ca77e5b", null ],
    [ "getWindowPosition", "class_min_g_l.html#a1ea6ea098988db36f5bf18713f9f3347", null ],
    [ "getWindowSize", "class_min_g_l.html#a92bacd1567089fb4641ed7b416cfe74d", null ],
    [ "initGraphic", "class_min_g_l.html#a5962a0a0ced7879bc0cc65e267e8d7fc", null ],
    [ "isOpen", "class_min_g_l.html#a05a0da9d0729e9c7dbd1121b0956866d", null ],
    [ "isPressed", "class_min_g_l.html#a8f0833403a4fb3df8010c132e81b207f", null ],
    [ "resetKey", "class_min_g_l.html#a99750fd4c8f97cfe693b1acb903424cf", null ],
    [ "setBackgroundColor", "class_min_g_l.html#a4399b7615cea89f850cd5c66e428c367", null ],
    [ "setWindowName", "class_min_g_l.html#a462ab2edc0eb28990638541873869e0e", null ],
    [ "setWindowPosition", "class_min_g_l.html#a9239873a52e437457af03f002f5df2b6", null ],
    [ "setWindowSize", "class_min_g_l.html#a532d320b7b837998533fe6577ab45bc3", null ],
    [ "stopGraphic", "class_min_g_l.html#a9508f3ac9d4cb4f444f56f5d77ed9d86", null ]
];