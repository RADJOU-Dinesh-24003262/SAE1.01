var hierarchy =
[
    [ "nsAudio::AudioEngine", "classns_audio_1_1_audio_engine.html", null ],
    [ "nsEvent::Event_t", "structns_event_1_1_event__t.html", null ],
    [ "nsEvent::EventData_t", "unionns_event_1_1_event_data__t.html", null ],
    [ "nsEvent::EventManager", "classns_event_1_1_event_manager.html", null ],
    [ "std::exception", null, [
      [ "nsException::CException", "classns_exception_1_1_c_exception.html", null ]
    ] ],
    [ "nsGui::GlutFont", "classns_gui_1_1_glut_font.html", null ],
    [ "nsGraphics::IDrawable", "classns_graphics_1_1_i_drawable.html", [
      [ "BgText", "class_bg_text.html", null ],
      [ "BgText", "class_bg_text.html", null ],
      [ "nsGui::Sprite", "classns_gui_1_1_sprite.html", null ],
      [ "nsGui::Text", "classns_gui_1_1_text.html", null ],
      [ "nsShape::Shape", "classns_shape_1_1_shape.html", [
        [ "nsShape::Circle", "classns_shape_1_1_circle.html", null ],
        [ "nsShape::Line", "classns_shape_1_1_line.html", null ],
        [ "nsShape::Rectangle", "classns_shape_1_1_rectangle.html", null ],
        [ "nsShape::Triangle", "classns_shape_1_1_triangle.html", null ]
      ] ]
    ] ],
    [ "nsUtil::IEditable", "classns_util_1_1_i_editable.html", [
      [ "nsException::CException", "classns_exception_1_1_c_exception.html", null ],
      [ "nsGraphics::RGBAcolor", "classns_graphics_1_1_r_g_b_acolor.html", null ],
      [ "nsGraphics::Vec2D", "classns_graphics_1_1_vec2_d.html", null ]
    ] ],
    [ "nsUtil::IFonctorUnaire< T1, TRes >", "classns_util_1_1_i_fonctor_unaire.html", null ],
    [ "nsTransition::ITransitionable", "classns_transition_1_1_i_transitionable.html", [
      [ "BgText", "class_bg_text.html", null ],
      [ "nsGui::Sprite", "classns_gui_1_1_sprite.html", null ],
      [ "nsGui::Text", "classns_gui_1_1_text.html", null ],
      [ "nsShape::Circle", "classns_shape_1_1_circle.html", null ],
      [ "nsShape::Line", "classns_shape_1_1_line.html", null ],
      [ "nsShape::Rectangle", "classns_shape_1_1_rectangle.html", null ],
      [ "nsShape::Triangle", "classns_shape_1_1_triangle.html", null ]
    ] ],
    [ "MinGL", "class_min_g_l.html", null ],
    [ "nsEvent::MouseClickData_t", "structns_event_1_1_mouse_click_data__t.html", null ],
    [ "nsEvent::MouseMoveData_t", "structns_event_1_1_mouse_move_data__t.html", null ],
    [ "nsTransition::TransitionContract", "classns_transition_1_1_transition_contract.html", [
      [ "nsTransition::Transition", "classns_transition_1_1_transition.html", null ]
    ] ],
    [ "nsTransition::TransitionEngine", "classns_transition_1_1_transition_engine.html", null ]
];