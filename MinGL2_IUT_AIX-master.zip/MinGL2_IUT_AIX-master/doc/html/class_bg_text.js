var class_bg_text =
[
    [ "TransitionIds", "class_bg_text.html#a5599f62d188a03c0bf5b51bb71f0ee95", [
      [ "TRANSITION_TEXT_COLOR", "class_bg_text.html#a5599f62d188a03c0bf5b51bb71f0ee95ac6cb4dc038246ac7206356a76bbdd1e3", null ],
      [ "TRANSITION_BACKGROUND_COLOR", "class_bg_text.html#a5599f62d188a03c0bf5b51bb71f0ee95a312ae9c6f63f2076bd975b165167c8e1", null ]
    ] ],
    [ "BgText", "class_bg_text.html#af1a6d5aba1d7276d6527cc1833d57dfa", null ],
    [ "~BgText", "class_bg_text.html#a19f8e1aa743e37d252b5b46ca98b7cd1", null ],
    [ "BgText", "class_bg_text.html#af1a6d5aba1d7276d6527cc1833d57dfa", null ],
    [ "~BgText", "class_bg_text.html#a19f8e1aa743e37d252b5b46ca98b7cd1", null ],
    [ "draw", "class_bg_text.html#a01df624a8d498766a9eb579eb18f2326", null ],
    [ "draw", "class_bg_text.html#a55fdeb5f3e12dcc2926c87f80fddc6c3", null ],
    [ "getValues", "class_bg_text.html#a01cc8269e39184b805351409aac4feb4", null ],
    [ "setValues", "class_bg_text.html#adb35c1e7e0387e04e8f8e67d9e1468c8", null ]
];